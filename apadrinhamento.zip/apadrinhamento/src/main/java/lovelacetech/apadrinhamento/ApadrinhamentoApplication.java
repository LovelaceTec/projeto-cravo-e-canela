package lovelacetech.apadrinhamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApadrinhamentoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApadrinhamentoApplication.class, args);
	}

}
